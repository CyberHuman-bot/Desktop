// Placeholder for network driver
