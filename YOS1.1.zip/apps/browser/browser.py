import tkinter as tk
from tkinter import ttk
import webbrowser

def open_browser():
    root = tk.Tk()
    root.title('YOS Browser')
    
    def load_url():
        url = url_entry.get()
        if not url.startswith('http'):
            url = 'http://' + url
        webbrowser.open(url)

    tk.Label(root, text='Enter URL:').pack(pady=5)
    url_entry = tk.Entry(root, width=50)
    url_entry.pack(pady=5)
    tk.Button(root, text='Go', command=load_url).pack(pady=10)

    root.mainloop()

if __name__ == '__main__':
    open_browser()
            